const router = require('express').Router();
const controller = require('./paymentController');
const auth = require('../../middleware/auth');

router.use(auth);

router.get('/', controller.getAll);
router.get('/:id', controller.getOne);
router.post('/', controller.create);
router.put('/:id', controller.update);
router.delete('/:id', controller.remove);

module.exports = router;
